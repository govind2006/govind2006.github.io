package com.swiggy.test;
import java.util.Random;

class Player{
	int health;
	int strength;
	int attack;
	Random random; // This is for generating random values for attacking and defending.
	
	public Player(int health, int strength, int attack) {
		this.health = health; 
		this.strength = strength;
		this.attack = attack;
		this.random=new Random();
	}

	public int getHealth() {
		return health;
	}
	
	// The attacking player rolls the attack dice.
	public int getAttack() {
		return random.nextInt(6)+1; //In a die, the values range from 1 to 6.
	}
	
	// The defending player rolls the defense dice.
	public int getDefend() {
		return random.nextInt(6)+1; //In a die, the values range from 1 to 6.
	}
	
	// Any damage inflicted by the attacker that exceeds the defender's defense will reduce the defender's health.
	public void reduceHealth(int damage) {
		health = health - damage;
	}
	
	boolean isPlayerAlive() {
		return health>0; // Checking if the player is alive or not.
	}
	
}

class MagicalArena{
	Player playerA;
	Player playerB;
	
	public MagicalArena(Player playerA, Player playerB) {
		this.playerA = playerA;
		this.playerB = playerB;
	}
	
	public void fight() {
		
		System.out.println("The players have now entered the arena.");
		
		Player attacker;
		Player defender;
		
		if(playerA.health>playerB.health) {
			attacker = playerB;
			defender = playerA;
		}else {
			attacker = playerA;
			defender = playerB;
		}
		
		while(playerA.isPlayerAlive() && playerB.isPlayerAlive()) {
			int attackNow = attacker.getAttack();
			int defendNow = defender.getDefend();
			
			int damage = attackNow*attacker.attack - defendNow*defender.strength;
			
			if(damage>0) {
				defender.reduceHealth(damage); // If the damage is greater than 0, then we reduce the health of the defender.
			}
			
			// Swap the player for next round;
			
			Player swap = attacker;
			attacker = defender;
			defender = swap;
		}
		
		if(playerA.isPlayerAlive()) {
			System.out.print("Player A wins");
		}else {
			System.out.print("Player B wins");
		}
	}
}

public class Main {
	public static void main(String[] args) {
		
		Player playerA = new Player(50,5,10);
		Player playerB = new Player(100,10,5);
		
		MagicalArena arena = new MagicalArena(playerA,playerB);
		arena.fight();
	}
}
