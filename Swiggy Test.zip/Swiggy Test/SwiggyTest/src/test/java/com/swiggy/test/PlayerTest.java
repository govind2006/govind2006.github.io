package com.swiggy.test;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class PlayerTest {

	@Test
	public void testAttack() {
		Player player = new Player(50,5,10);
		int attacker = player.getAttack();
		
		// The attack value must range between 1 and 6.
		assertTrue(attacker>=1 && attacker<=6);
	}
	
	@Test
	public void testDefend() {
		Player player = new Player(100,10,5);
		int defender = player.getDefend();
		
		// The defend value must range between 1 and 6.
		assertTrue(defender>=1 && defender<=6); 
	}
}
